import boto3
import json
#import pprint
import datetime
import os
from botocore.config import Config

# Function that is used when converting to json to sterlise if value is datetime
def json_datetime_converter(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()

# Function that converts data to json and saves to file
def json_convert_write_file(data_to_write, filename, open_option):
    data_to_write_json = json.dumps(data_to_write, indent = 4,
                                    default = json_datetime_converter)
    # write json to file
    f = open(filename, open_option)
    f.write(data_to_write_json)
    f.close()

# Initiate boto3 clients
config = Config(
    retries = {
        'max_attempts': 100,
        'mode': 'adaptive'
        })
s3 = boto3.client('s3')
azn_connect = boto3.client('connect', config=config)
### Start of backing up Instance basics
instances_raw = azn_connect.list_instances()
# creates a variables that just contains the Instance list
instances = instances_raw['InstanceSummaryList']
instances_num = len(instances)

print('\nNumber of Connect Instances : ' + str(instances_num))

current_date = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')

for instance in instances:
    contact_flow_types=[
        'CONTACT_FLOW','CUSTOMER_QUEUE','CUSTOMER_HOLD','CUSTOMER_WHISPER','AGENT_HOLD','AGENT_WHISPER','OUTBOUND_WHISPER','AGENT_TRANSFER','QUEUE_TRANSFER',
    ]
    contact_flow_list_raw = azn_connect.list_contact_flows(InstanceId=instance['Id'], ContactFlowTypes=contact_flow_types)
    contact_flow_list = contact_flow_list_raw['ContactFlowSummaryList']

    #print(contact_flow_list)

    contact_flows_backedup = {}
    contact_flows_not_backedup = {}

    for contact_flow in contact_flow_list:
        try:
            contact_flow_raw = azn_connect.describe_contact_flow(InstanceId=instance['Id'], ContactFlowId=contact_flow['Id'])
            #print(contact_flow_raw)
            print("Backed Up - "+contact_flow['Name'])
            contact_flows_backedup.update({contact_flow['Name'] : contact_flow})

            # backup contact flow to xml file
            contact_flow_xml = contact_flow_raw['ContactFlow']['Content']
            # write json to file
            # make contact flow name a useable file name
            contact_flow_file_safe_name = contact_flow['Name'].replace(" ", "-")
            contact_flow_file_safe_name = contact_flow_file_safe_name.replace("---", "-")
            contact_flow_file_safe_name = contact_flow_file_safe_name.replace("--", "-")

            xml_file = current_date+'_'+instance['InstanceAlias']+'.contact_flow.'+contact_flow_file_safe_name+'.xml'

            xml = open(xml_file, 'w')
            xml.write(contact_flow_xml)
            xml.close()

        except:
            contact_flows_not_backedup.update({contact_flow['Name'] : contact_flow})
            print("NOT Backed Up - "+contact_flow['Name'])

contact_flows_backedup_file = current_date+'_'+instance['InstanceAlias']+'.contact_flows_backedup.config'
json_convert_write_file(contact_flows_backedup, contact_flows_backedup_file, 'w')
contact_flows_not_backedup_file = current_date+'_'+instance['InstanceAlias']+'.contact_flows_not_backedup.config'
json_convert_write_file(contact_flows_not_backedup, contact_flows_not_backedup_file, 'w')
    


